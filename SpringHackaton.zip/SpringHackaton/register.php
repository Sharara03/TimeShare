<?php

include("sqlib.php");

ob_start();
$db = create_db("ts");

echo "1234567890";


if(isset($_POST["go"]))
{
echo $name = filtr($_POST["name"]);
echo $surname = filtr( $_POST["surname"]);
echo $birthdate = filtr( $_POST["birthdate"]);

echo $about =  filtr($_POST["about"]);
echo $email =  filtr($_POST["email"]);
echo $phone =  filtr($_POST["phone"]);
echo $password = filtr( $_POST["password"]);
echo $confirm =  filtr($_POST["confirm"]);
echo $activity =  filtr($_POST["activity"]);

if($password!=$confirm)
{header("location: volunteer.php?pass_error=1");}
else{

	if(isset($_FILES['uploadfile']['name'])){
		copy($_FILES['uploadfile']['tmp_name'],"server/volunteer_rl/".basename($_FILES['uploadfile']['name']));
	$volunteer_rl=basename($_FILES['uploadfile']['name']);
	echo $volunteer_rl = filtr($volunteer_rl);

	}
	if(isset($_FILES['uploadfoto']['name'])){
		copy($_FILES['uploadfoto']['tmp_name'],"server/volunteer_img/".basename($_FILES['uploadfoto']['name']));
			echo	$volunteer_img=basename($_FILES['uploadfile']['name']);
				echo $volunteer_img = filtr($volunteer_img);
	}

		

$cr_code = md5($name.$birthdate.$phone.$email);

insert_c($db, "users", array(
"name"=>$name, 
"surname"=>$surname, 
"birthdate"=>$birthdate, 
"about"=>$about, 
"recomendation"=>$volunteer_rl, 
"foto"=>$volunteer_img, 
"phone"=>$phone, 
"email"=>$email, 
"password"=>$password,
"activity" => $activity,
"volunteer_code"=>$cr_code
)); 



$vol = select($db, "users", "volunteer_code", $cr_code);
$vol_id = $vol[0]["id"];


 setcookie(
  "volunteer",
  $vol_id,
  time() + (120000000)
);

header("location:volunteertable.php");
	
}
}


//drop_tb($db,"users");

	//add_column($db, "users", "volunteer_code");
//create_tb($db,"users", array("name", "surname", "birthdate", "about", "activity", "recomendation", "foto","phone" ,"email", "password"));

//insert_c($db, "users", array("name"=>"dildora", "surname"=>"nishanova", "birthdate"=>"06.02.03", "about"=>"its me", "recomendation"=>"file1.png", "foto"=>"DS8237.jpg", "email"=>"dil@mail.ru", "password"=>"123456"));
//insert_c($db, "users", array("name"=>"dilnoza", "surname"=>"nishanova", "birthdate"=>"10.07.05", "about"=>"im so chic", "recomendation"=>"file2.png", "foto"=>"DS8987.jpg", "email"=>"chic@mail.ru", "password"=>"12345"));

//view_tb($db, "users");

//delete($db, "users", "name", "dildora");

//view_tb($db, "users");

//$res = select($db, "users", 2);

//print_r($res);

//echo $res["email"];
//echo $res["password"];

//$res_select = select_c($db, "users", "id, name, surname");

//print_r($res_select);

//echo $res_select[0]["name"];

//update($db, "users", "about", "im so chic", "id", "1");

view_tb($db, "users");


$db = create_db("ts");
 create_tb($db,"parents", array("name", "surname", "birthdate", "passport", "email","phone", "password"));

 
 //parents table
 if(isset($_POST["go2"]))
{
echo $name = filtr($_POST["name"]);
echo $surname = filtr($_POST["surname"]);
echo $birthdate = filtr($_POST["birthdate"]);
echo $passport = filtr($_POST["passport"]);
echo $email = filtr($_POST["email"]);
echo $phone = filtr($_POST["phone"]);
echo $password =filtr( $_POST["password"]);
echo $confirm =filtr( $_POST["confirm"]);
if($password!=$confirm)
{header("location: parents.php?pass_error=1");}
else{

$cr_code = md5($name.$birthdate.$phone.$email);

 insert_c($db, "parents", array("name"=>$name, 
													"surname"=>$surname, 
													"birthdate"=>$birthdate,
													"passport"=>$passport,
													"email"=>$email, 
													"phone"=>$phone,
													"password"=>$password,
													"parent_code"=>$cr_code));
													
													
$vol = select($db, "parents", "parent_code", $cr_code);
$vol_id = $vol[0]["id"];

header("location: parent_cabinet.php?parent_name=".$name."&parent_surname=".$surname."&parent_phone=".$phone);


 setcookie(
  "parent",
  $vol_id,
  time() + (120)
);
	
		
   }										
}
view_tb($db, "parents");
	

//create_tb($base,"children",array("name","surname","date_of_birth","bio","foto"));



//add_column($db,"parents","parent_code");




if(isset($_POST["go3"]))
{
echo $name = filtr($_POST["name"]);
echo $surname = filtr( $_POST["surname"]);
echo $birthdate = filtr( $_POST["date_of_birth"]);
echo $about =  filtr($_POST["bio"]);
echo $activity =  filtr($_POST["activity"]);
echo $parent_name =  filtr($_POST["parent_name"]);
echo $parent_surname =  filtr($_POST["parent_surname"]);
echo $parent_phone =  filtr($_POST["parent_phone"]);
echo $code =  filtr($_POST["code"]);


if(isset($_FILES['uploadfoto']['name'])){
		copy($_FILES['uploadfoto']['tmp_name'],"server/children/".basename($_FILES['uploadfoto']['name']));
			echo	$children=basename($_FILES['uploadfoto']['name']);
				echo $children = filtr($children);
	}

 insert_c($db, "children", array(
"name"=>$name, 
"surname"=>$surname, 
"date_of_birth"=>$birthdate, 
"bio"=>$about, 
"foto"=>$children,
"activity" => $activity,
"parent_name" => $parent_name,
"parent_surname" => $parent_surname,
"parent_phone" => $parent_phone,
"code" => $code,
)); 

		header("location: volontyortable.php?code=".$code);
}
//drop_tb($db,"children");
//create_tb($db,"children",array("name","surname","date_of_birth","bio","foto", "volunteer", "parent_name", "parent_surname", "parent_phone","activity", "code"));



//if(isset($_POST["volunteer_id"]))
//{
//echo $volunteer_id = filtr($_POST["volunteer_id"]);
//
//
//	
//		header("location: volontyortable.php");
//	
//
// insert_c($db, "children", array(
//"name"=>$name, 
//"surname"=>$surname, 
//"date_of_birth"=>$birthdate, 
//"bio"=>$about, 
//"foto"=>$children,
//"activity" => $activity
//)); 
//
//}
//



if(isset($_POST["childrens_volunteer"]))
{
echo $volunteer_id = filtr($_POST["volunteer_id"]);
echo $code = filtr($_POST["code"]);
$childrens_volunteer = filtr($_POST["childrens_volunteer"]);

$chil = select($db, "children", "code", $code);
$children_id = $chil[0]["id"];

update($db, "children", "volunteer", $volunteer_id, "id", $children_id);
	
		header("location: parenttable.php");
	


}






view_tb($db,"children");



?>


