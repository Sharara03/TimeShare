<footer class="bg-primary" id="about" style="background-color:#41aec0;">
         <div class="container">
            <div class="row text-center">
               <!-- social media and logo -->
               <div class="col-lg-4">
                  <h6  class="text-light">Opening Times</h6>
                  <ul class="ul-custom ul-no-margin text-light">
                     <li>Mon - fri: 9am-6pm</li>
                     <li>Holidays: Closed</li>
                  </ul>
               </div>
               <!-- /row -->
               <div class="col-lg-4">
                  <a href="#page-top"><img src="tayyor.png"  alt="" class="img-responsive center-block" style="height:150px"></a>
               </div>
               <div class="col-lg-4">
                  <!-- social-icons -->	
                  <h6  class="text-light">Follow us</h6>
                  <div class="social-media">
                     <a href="#" title=""><i class="fa fa-twitter"></i></a>
                     <a href="#" title=""><i class="fa fa-facebook"></i></a>
                     <a href="#" title=""><i class="fa fa-instagram"></i></a>
                  </div>
               </div>
               <!-- /col-lg-4 -->  			
            </div>
            <!-- /row -->
            <div class="row">
               <div class="col-md-12 credits text-center">
                  <p>Copyright © 2019 - Designed by  <a href="http://www.CyberKids.com">Cyber Kids</a></p>
                  <!-- /container -->
                  <!-- Go To Top Link -->
                  <div class="page-scroll hidden-sm hidden-xs">
                     <a href="#page-top" class="back-to-top"><i class="fa fa-angle-up"></i></a>
                  </div>
               </div>
               <!-- /col-md-12 -->
            </div>
            <!-- /row-->
         </div>
         <!-- /container -->
      </footer>
            <!-- Core JavaScript Files -->
            <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Main Js -->
      <script src="js/main.js"></script>
      <!-- Open street maps -->
      <script src="js/map.js"></script>
      <!-- MailChimp Validator -->
      <script src="js/mc-validate.js"></script>
      <!-- GreenSock -->
      <script src="js/layerslider/js/greensock.js"></script>
      <!-- LayerSlider Script files -->
      <script src="js/layerslider/js/layerslider.transitions.js"></script>
      <script src="js/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
      <script src="js/layerslider/js/layerslider.load.js"></script>
      <!-- Other Plugins -->
      <script src="js/plugins.js"></script>
      <!-- Prefix Free CSS -->
      <script src="js/prefixfree.js"></script>	  
      <!-- Counter -->
      <script src="js/counter.js"></script>  	