<?php include("control.php"); ?>

<!DOCTYPE html>
<html lang="en">
   <?php
     
   ?>
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
<?php
      include_once "navbar.php";
   ?>
<section id="contact" class="container-fluid">
         <div  class="container">
            <div class="col-lg-12">
               <!-- Section heading -->
               <div class="section-heading">
                  <h2 style="margin-top:100px ;">Contact Us</h2>
               </div>
            </div>
            <!-- Contact icons -->
            <div class="row">
               <div style="margin-top:50px ;" class="col-lg-12 col-md-12">
                  <div class="col-md-4">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-envelope top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Send us a Message</p>
                           <p>Email address: <br/><a href="mailto:email@timeshare.com">email@timeshare.com</a></p>
                        </div>
                     </div>
                  </div>
                  <!-- /contact-icon-->
                  <div class="col-md-4">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-map-marker top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Visit our Location</p>
                           <p>Almazar district 1-a house<br/>Tashkent</p>
                        </div>
                     </div>
                  </div>
                  <!-- /contact-icon-->
                  <div class="col-md-4">
                     <div class="contact-icon res-margin">
                        <!---icon-->
                        <i class="fa fa-phone top-icon"></i>
                        <!-- contact-icon info-->
                        <div class="contact-icon-info">
                           <p class="subtitle">Call us</p>
                           <p>Phone numbers: <br/>(94) 123-45-67 <br/>(94) 123-45-67</p>
                        </div>
                     </div>
                     <!-- /contact-icon-->
                  </div>
                  <!-- /col-md-4-->
               </div>
               <!-- /col-lg -->
            </div>
            <div class="row margin1">
               
               <!-- / col-md-5-->
               <!-- Map with Reveal Box -->
               <div class="col-md-6 col-md-offset-1 revealedBox goLeft res-margin">
                  <!-- Map -->
                  <div height="0" class="" id="map-canvas">                      
               
               </div>

               <!--/col-lg-6  -->
            </div>
            <!--/row -->   
         </div>
         <!-- /container-->
      </section> 
      <?php
         include_once "footer.php";
      ?>
</body>
</html>