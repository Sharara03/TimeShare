-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 16, 2023 at 05:20 AM
-- Server version: 8.0.30
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbspring1`
--

-- --------------------------------------------------------

--
-- Table structure for table `eventss`
--

CREATE TABLE `eventss` (
  `Id` int NOT NULL,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Date` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Place` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `Time` time NOT NULL,
  `Photo` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `eventss`
--

INSERT INTO `eventss` (`Id`, `Name`, `Date`, `Place`, `Time`, `Photo`) VALUES
(1, 'Bingo game', '2022-12-28', 'Asosiy bino', '15:00:00', 'bingo.png'),
(2, 'Conversation club', '2022-12-27', 'Humo Arena', '17:00:00', 'conversation.png'),
(3, 'Book club', '2022-12-29', 'Kutubxona', '14:00:00', 'book.png'),
(4, 'Danca klass-master', '2022-12-22', 'Musiqa xonasi', '14:00:00', 'dance.png'),
(5, 'Making houses', '2022-12-27', 'Eko-park', '16:30:00', 'house.png'),
(6, 'Making healty food', '2022-12-28', 'Oshxona', '18:00:00', 'food.png');

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `id` int NOT NULL,
  `nameParent` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `surnameParent` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` date NOT NULL,
  `passport` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `nameChild` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `surnameChild` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdateChild` date NOT NULL,
  `bio` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `event` int NOT NULL,
  `childPic` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `volunteer` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `bdate` date NOT NULL,
  `about` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `number` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `volunteers`
--

INSERT INTO `volunteers` (`id`, `name`, `surname`, `bdate`, `about`, `photo`, `number`, `email`, `event_id`) VALUES
(4, 'Anna ', 'Washington', '2003-03-13', 'I am a person who is positive about every aspect of life. There are many things I like to do, to see, and to experience. I like to read, I like to write; I like to think, I like to dream; I like to talk, I like to listen. I like to see the sunrise in the morning, I like to see the moonlight at night; I like to feel the music flowing on my face, I like to smell the wind coming from the ocean. I like to look at the clouds in the sky with a blank mind, I like to do thought experiment when I cannot sleep in the middle of the night.', 'team-1.jpg', '+998 94 5486644', 'annawashington@yandex.com', 4),
(5, 'Valentina', 'Sophia', '1997-06-27', 'As a general manager, I\'ve helped direct store operations for three locations. My dedication to mentoring and helping others has helped me create successful teams that support each other. My enthusiasm, dedication and desire to improve operations can help me improve your company\'s performance.', 'team-2.jpg', '+998 97 565 6556', 'valetina@gmail.com', 3),
(6, 'Thomas', 'Edison', '2023-01-26', 'Passion, patience and understanding are three essential qualities I\'ve developed as an early childhood educator. These values have helped me educate over 300 students throughout my educator career. My experience and love for education can enable me to help your child reach their educational goals.', 'team-3.jpg', '+998 69 5455555', 'thomasss@gmail.com', 6),
(7, 'JAne', 'Austin', '1995-10-12', 'Passion, patience and understanding are three essential qualities I\'ve developed as an early childhood educator. These values have helped me educate over 300 students throughout my educator career. My experience and love for education can enable me to help your child reach their educational goals.', 'team-4.jpg', '+998 76 455 5656', 'jaaustin@gmail.com', 6),
(8, 'Shahzoda', 'Yunusaliyeva', '2006-03-03', 'Shahzoda is a well-versed administrative assistant and office manager with five years of experience providing tailored support. Helping others and sharing knowledge are two beliefs Shahzoda imparts every day. Her experience, positive attitude and willingness to help others allow her to excel in administrative roles.', '27photo_2023-03-16_06-45-39.jpg', '+998936561606', 'alemovna33@gmail.com', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eventss`
--
ALTER TABLE `eventss`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event` (`event`,`volunteer`),
  ADD KEY `volunteer` (`volunteer`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `event` (`event_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `eventss`
--
ALTER TABLE `eventss`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `parents_ibfk_1` FOREIGN KEY (`event`) REFERENCES `eventss` (`Id`),
  ADD CONSTRAINT `parents_ibfk_2` FOREIGN KEY (`volunteer`) REFERENCES `volunteers` (`id`);

--
-- Constraints for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `volunteers_ibfk_1` FOREIGN KEY (`event_id`) REFERENCES `eventss` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
