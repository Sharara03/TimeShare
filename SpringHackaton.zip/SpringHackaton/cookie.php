<?php
	$strName=$_COOKIE['bbb'];
	if(strName=="gitsal"){
		echo "1  1";
	}
	else{
		echo "0  0";
	
	}
	if(isset($_GET['kod'])){
	if($_GET['kod']=="dildora"){
		echo "  3983";
		setcookie("Name","gitsal",time()+10);
	}
	else{
	echo "0";
	}}
	?>
	<form action="cookie.php" method="GET">
	<input type="text" name="kod">
	<input type="submit"  value="Login">
	</form>