<?php
    include_once "connect.php";
    $query = "SELECT * FROM eventss";
    $result = mysqli_query($connect, $query);
?>
<?php include("control.php"); ?>

<!DOCTYPE html>
<html lang="en">
   <?php
     
   ?>
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
<?php
      include_once "navbar.php";
   ?>
       <section id="blog-preview">
         <div class="container">
            <!-- Section Heading -->
            <div class="section-heading">
               <h2 style="margin-top: 150px;">Events</h2>
                
            </div>
            <div class="col-md-11">
                  <!-- ==== Blog post 1 ==== -->
                    <?php
                        while($row = mysqli_fetch_assoc($result)){
                    ?>
                    <div class="blog-prev border-dotted" style="margin-top: 30px">
                        <!-- image -->
                        <img src="img/event/<?=$row['Photo']?>" alt="" class="img-responsive col-11"/>
                        <!-- date -->
                        <!-- <div class="date"><?php //$row['Date']?></div> -->
                        <!-- caption -->
                        <div class="blog-caption">
                            <a href="blog-single.html">
                            <h5><?=$row['Name']?></h5>
                            </a>
                            <p>
                            <?=$row['About']?>
                            <p><i class="fa fa-map-marker"></i>  <?=$row['Place']?></a></p>
                            <p><i class="fa fa-calendar"></i>  <?=$row['Date']?></a></p>
                            <p><i class="fa fa-clock-o"></i>  <?=$row['Time']?></a></p>

                            </p>

                        </div>
                        <!-- /blog-caption -->
                    </div>
                    <?php } ?>

                  <!--/blog-prev -->
               </div>
            <!--/col-md-12 -->
         </div>
         <!--/container -->
      </section>
      <!-- /section -->

      <!--============== Footer Starts ==============-->
    <footer class="bg-primary" id="about" style="background-color:#41aec0;">
         <div class="container">
            <div class="row text-center">
               <!-- social media and logo -->
               <div class="col-lg-4">
                  <h6  class="text-light">Opening Times</h6>
                  <ul class="ul-custom ul-no-margin text-light">
                     <li>Mon - fri: 9am-6pm</li>
                     <li>Holidays: Closed</li>
                  </ul>
               </div>
               <!-- /row -->
               <div class="col-lg-4">
                  <a href="#page-top"><img src="tayyor.png"  alt="" class="img-responsive center-block" style="height:150px"></a>
               </div>
               <div class="col-lg-4">
                  <!-- social-icons -->	
                  <h6  class="text-light">Follow us</h6>
                  <div class="social-media">
                     <a href="#" title=""><i class="fa fa-twitter"></i></a>
                     <a href="#" title=""><i class="fa fa-facebook"></i></a>
                     <a href="#" title=""><i class="fa fa-instagram"></i></a>
                  </div>
               </div>
               <!-- /col-lg-4 -->  			
            </div>
            <!-- /row -->
            <div class="row">
               <div class="col-md-12 credits text-center">
                  <p>Copyright © 2019 - Designed by  <a href="http://www.CyberKids.com">Cyber Kids</a></p>
                  <!-- /container -->
                  <!-- Go To Top Link -->
                  <div class="page-scroll hidden-sm hidden-xs">
                     <a href="#page-top" class="back-to-top"><i class="fa fa-angle-up"></i></a>
                  </div>
               </div>
               <!-- /col-md-12 -->
            </div>
            <!-- /row-->
         </div>
         <!-- /container -->
      </footer>
      <!-- Core JavaScript Files -->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Main Js -->
      <script src="js/main.js"></script>
      <!-- Open street maps -->
      <script src="js/map.js"></script>
      <!-- MailChimp Validator -->
      <script src="js/mc-validate.js"></script>
      <!-- GreenSock -->
      <script src="js/layerslider/js/greensock.js"></script>
      <!-- LayerSlider Script files -->
      <script src="js/layerslider/js/layerslider.transitions.js"></script>
      <script src="js/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
      <script src="js/layerslider/js/layerslider.load.js"></script>
      <!-- Other Plugins -->
      <script src="js/plugins.js"></script>
      <!-- Prefix Free CSS -->
      <script src="js/prefixfree.js"></script>	  
      <!-- Counter -->
      <script src="js/counter.js"></script>  	  
   </body>
</html>