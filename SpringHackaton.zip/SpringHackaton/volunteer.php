<?php 

include_once "connect.php";
$surov3="SELECT * FROM Eventss;";
$query3= mysqli_query($connect,$surov3);
echo "-------------";


  
   if (isset($_POST['submit']) && $_FILES['fayl']['error'] == 0) {
      $name = addslashes($_POST['name']);
      $surname = addslashes($_POST['surname']);
      $bdate = addslashes($_POST['bdate']);
      $about = addslashes($_POST['about']);
      $email = addslashes($_POST['email']);
      $number = addslashes($_POST['number']);
      $event_id = $_POST['event_id'];
      
      $fayl_nomi= rand(1,40).$_FILES['fayl']['name'];
      $tmp_joy=$_FILES['fayl']['tmp_name'];
      $fayl_joyi=$_SERVER['DOCUMENT_ROOT'].'/img/volunteers/'.$fayl_nomi;
      move_uploaded_file($tmp_joy,$fayl_joyi);
      include_once "connect.php";
      $surov2 = "INSERT INTO `volunteers`( `name`, `surname`, `bdate`, `about`, `photo`, `number`, `email`, `event_id`) VALUES ('$name','$surname','$bdate','$about','$fayl_nomi','$number','$email', '$event_id')";
      echo "INSERT INTO `volunteers`( `name`, `surname`, `bdate`, `about`, `photo`, `number`, `email`, `event_id`) VALUES ('$name','$surname','$bdate','$about','$fayl_nomi','$number','$email', '$event_id')";
      $query2 = mysqli_query($connect,$surov2);
      if ($query2 == true) {
         header('location:index.php');
      } else{
         echo "so'rovda xatolik bor<br>";
         echo $_POST['event_id'];
      }
   }
   else{
      echo"rasmni yuklashda xatolik bor";
      echo $_POST['event_id'];   
      echo "INSERT INTO `volunteers`( `name`, `surname`, `bdate`, `about`, `photo`, `number`, `email`, `event_id`) VALUES ('$name','$surname','$bdate','$about','$fayl_nomi','$number','$email', '$event_id')";   
   }
    

?>



<!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="utf-8">
      <!--[if IE]>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <![endif]-->
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- Page title -->
      <title>Time Share</title>
      <!--[if lt IE 9]>
      <script src="js/respond.js"></script>
      <![endif]-->
      <!-- Bootstrap Core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet" type="text/css">
      <!-- Icon fonts -->
      <link href="fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
      <link href="fonts/flaticons/flaticon.css" rel="stylesheet" type="text/css">
      <link href="fonts/glyphicons/bootstrap-glyphicons.css" rel="stylesheet" type="text/css">
      <!-- Google fonts -->
      <link href="https://fonts.googleapis.com/css?family=Karla:400,600,700%7CCherry+Swash:400,700" rel="stylesheet">
      <!-- Style CSS -->
      <link href="css\style.css" rel="stylesheet">
      <!-- Color Style CSS -->
      <link href="styles/maincolors.css" rel="stylesheet">
      <!-- CSS Plugins -->
      <link rel="stylesheet" href="css/plugins.css">
      <!-- LayerSlider CSS -->
      <link rel="stylesheet" href="js/layerslider/css/layerslider.css">
      <!-- Favicons-->
      <link rel="apple-touch-icon" sizes="72x72" href="apple-icon-72x72.png">
      <link rel="apple-touch-icon" sizes="114x114" href="apple-icon-114x114.png">
      <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
   </head>
   <?php
      include_once "navbar.php";
   ?>
   <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
   
			
     
	 
      
      <!-- /curve up svg -->

      <!-- ==== Contact ==== -->
      <section id="contact" class="container-fluid cake-ornament">
         <div class="container">
		 <div class="row margin1">
               <div class="col-md-12">

                  <div class="form-style" id="contact_form">
                     <!-- Contact Form -->
                     <!-- Form Starts -->
                     <div class="form-group">
					 
					 <h2 style="margin-top: 60px;">Registration</h2>
					 <form  method="post" enctype="multipart/form-data">
                        <label>Name<span class="required">*</span></label>
                        <input required type="text" name="name" class="form-control input-field" placeholder="" required="">                    
                        <label>Surname<span class="required">*</span></label>
                        <input required type="text" name="surname" class="form-control input-field" placeholder="" required=""> 
                        <label>Date of birth</label>						
                        <input required type="date" name="bdate" class="form-control input-field" placeholder="">                                          
                        <label>Write about yourself<span class="required">*</span></label>
                        <textarea name="about" type="text" class="textarea-field form-control" rows="4" placeholder="" required=""></textarea>
						      <br>
						      <label>Choose the event<span class="required">*</span></label>
                        <select class="form-control input-field" name="event_id"  >
                        <option selected value=""></option>
                              <?php
                                 while($rowe = mysqli_fetch_assoc($query3)){
                              ?>
                                 <option value="<?=$rowe['Id']?>"><?=$rowe['Name']?></option>
                              <?php
                                 }
                              ?>
                           </select> 
                          
                   
                           
                        <br>
						         <label>Your photo</label>						
                              <input type="file" name="fayl" class="form-control input-field" placeholder=""> 
						         <label>Phone number</label>						
                              <input type="text" name="number" class="form-control input-field" placeholder=""> 
						         <label>E-mail</label>
						            <input type="text" name="email" class="form-control input-field" placeholder="">
						            <button type="submit" name="submit" class="blob-btn" value="Go" id="submit_btn"  placeholder="">
					                  Go!
                                 <span class="blob-btn__inner">
                                 <span class="blob-btn__blobs">
                                 <span class="blob-btn__blob"></span>
                                 <span class="blob-btn__blob"></span>
                                 <span class="blob-btn__blob"></span>
                                 <span class="blob-btn__blob"></span>
                                 </span>
                                 </span>
                              </button>
						      </form>
                     </div>
                     <!-- Contact results -->
                     <div id="contact_results"></div>
                  </div>
                  <!--/Contact_form -->
               </div>
               <!-- / col-md-5-->

               <!--/col-lg-6  -->
            </div>
            <!--/row -->   
         </div>
         <!-- /container-->
      </section>
      <?php
         include_once "footer.php";
      ?>
      <!-- / section-->
	  <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <!-- Main Js -->
      <script src="js/main.js"></script>
      <!-- Open street maps -->
      <script src="js/map.js"></script>
      <!-- MailChimp Validator -->
      <script src="js/mc-validate.js"></script>
      <!-- GreenSock -->
      <script src="js/layerslider/js/greensock.js"></script>
      <!-- LayerSlider Script files -->
      <script src="js/layerslider/js/layerslider.transitions.js"></script>
      <script src="js/layerslider/js/layerslider.kreaturamedia.jquery.js"></script>
      <script src="js/layerslider/js/layerslider.load.js"></script>
      <!-- Other Plugins -->
      <script src="js/plugins.js"></script>
      <!-- Prefix Free CSS -->
      <script src="js/prefixfree.js"></script>	  
      <!-- Counter -->
      <script src="js/counter.js"></script>  	  
   </body>
</html>