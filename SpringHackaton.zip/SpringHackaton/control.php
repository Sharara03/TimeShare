<?php

if(isset($_COOKIE["parent"]))
{
	header("location: parenttable.php");
}

elseif(isset($_COOKIE["volunteer"]))
{
	header("location: volunteertable.php");
} 

else
{

} 